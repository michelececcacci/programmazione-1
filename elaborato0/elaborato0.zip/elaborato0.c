#include <stdio.h>

int main(void){
    printf("Michele Ceccacci\n Matricola 0001027124\n Gruppo 42\n")
}
